

-- start


function onResourceStart()
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), onResourceStart)

--- pojazd




txd = engineLoadTXD ( "ballypillar01.txd" )
engineImportTXD ( txd, 3437 )  

billboard = engineLoadTXD("8558.txd")
engineImportTXD(billboard, 8558 )
billboard = engineLoadTXD("3458.txd")
engineImportTXD(billboard, 3458 )
billboard = engineLoadTXD("8838.txd")
engineImportTXD(billboard, 8838 )

addEventHandler( "onClientResourceStart", getResourceRootElement(getThisResource()), chat )

outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 255, 255, 255, true)
outputChatBox ("", 27, 89, 224, true)
outputChatBox ("", 27, 89, 224, true)
outputChatBox ("", 27, 89, 224, true)
outputChatBox ("#0070FFFtF!/X#88FF00peria#<~#ffffff: Song Name: Fetty Wap - Trap Queen (Crankdat Remix) [Bass Boosted] ", 27, 89, 224, true)
   


