function startclient ()
	outputChatBox ( "This map have built-in Ghost mode. Admins shouldnt enable ghostmode manually on such maps" , 255, 255, 255, true )	
end 

addEventHandler( "onClientResourceStart", getRootElement(), startclient )


